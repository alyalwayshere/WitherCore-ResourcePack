WitherCore All 8 Weapons Resource Pack (Held-Position Fix)

Changes in this version:
- Includes all 8 custom weapons.
- Fixed the held position by adding explicit first-person and third-person display transforms.
- Fixed the flipped mace texture (Celestial Judgement).
- Compatible with your existing item IDs, including wither_relic.

Install:
1. Put this ZIP in %appdata%\.minecraft\resourcepacks
2. Enable it in Minecraft.
3. Keep the ZIP compressed.
